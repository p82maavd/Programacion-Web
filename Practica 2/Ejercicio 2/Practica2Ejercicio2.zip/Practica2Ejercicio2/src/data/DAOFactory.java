package data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DAOFactory {
	
	private static DAOFactory instance=null;
	private Connection con;
	// method to create connections
	public void createConnection() {
		
		try {
		  Class.forName("com.mysql.jdbc.Driver");
		  
		  this.con= DriverManager.getConnection("jdbc:mysql://oraclepr.uco.es:3306/p82maavd","p82maavd","1234");
		  
		  if(this.con==null) {
			  System.out.println("Vaya chufla de bd");
		  }
		
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		
	}
	private DAOFactory() {
		createConnection();
	}
	public static DAOFactory getInstance() {
		if(instance==null) {
			instance=new DAOFactory();
			return instance;
		}
		
		return instance;
	}
	public Connection getCon() {
		return con;
	}
	public void setCon(Connection con) {
		this.con = con;
	}
	public ContactoDAO getContactoDAO() throws SQLException, FileNotFoundException, ClassNotFoundException, IOException {
		
		return ContactoDAO.getInstance(getCon());
		
	}
	public AnuncioDAO getAnuncioDAO() throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		
		return AnuncioDAO.getInstance(this.con);
	}
	
	public InteresDAO getInteresDAO() throws FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		
		if(this.con!=null) {
			return  InteresDAO.getInstance(this.con);
		}
		System.out.println("No se establece la conexion");
		return null;
		
	}
	
		  

}