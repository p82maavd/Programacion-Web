package data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import business.Contacto;

public interface ContactoDAOInterface {
	
	public void crearContacto(Contacto e) throws SQLException, FileNotFoundException, ClassNotFoundException, IOException;
	public void borrarContacto(Contacto e) throws SQLException, FileNotFoundException, ClassNotFoundException, IOException;

	
}