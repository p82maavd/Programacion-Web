package data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;
import business.Contacto;
import business.Interes;
import business.Anuncio;

public class ContactoDAO implements ContactoDAOInterface {

	
	private Connection con=null;
	
	private ControlDeErrores control=new ControlDeErrores();
	
	private DAOFactory factory=DAOFactory.getInstance();
	
	private InteresDAO interesesDAO= factory.getInteresDAO();
	private AnuncioDAO anunciosDAO;
	Configuracion config;
	
	private static ContactoDAO instance =null;
	
	private ContactoDAO(Connection e) throws SQLException, FileNotFoundException, ClassNotFoundException, IOException {
		this.con=e;
		
		config= Configuracion.getInstance(null);
		
	}
	
	public static ContactoDAO getInstance(Connection e) throws FileNotFoundException, ClassNotFoundException, SQLException, IOException {
		
		if(instance==null) {
			instance=new ContactoDAO(e);
			return instance;
		}
		return instance;
	}
	
	public ArrayList<Contacto> getContactos() throws SQLException{
		Statement stmt=con.createStatement();
		ResultSet rs= stmt.executeQuery(config.getProperty("OBTENER_CONTACTOS"));
		ArrayList<Contacto> contactos =new ArrayList<Contacto>();
		ArrayList<Interes> interesesaux = new ArrayList<Interes>();
		String email= new String();
		String nombre= new String();
		String apellidos= new String();
		String password = new String();
		Date date= new Date(0);
		Contacto a = null;
		
		try {
			
			while(rs.next()) {
				
				email = rs.getString(1);
				nombre=rs.getString(2);
				apellidos=rs.getString(3);
				date=rs.getDate(4);
				password=rs.getString(5);
				interesesaux=interesesDAO.getInteresesContacto(email);
				
				a=new Contacto(email,nombre,apellidos,date,password,interesesaux);
				contactos.add(a);
				
			}
		
		}catch(Exception e) {
			System.out.println("Error al cargar los contactos de la Base de Datos");
		}
		return contactos;
		
	}
	
	@Override
	public void crearContacto(Contacto e) throws SQLException, FileNotFoundException, ClassNotFoundException, IOException {
		anunciosDAO= factory.getAnuncioDAO();
		if(e == null) {
			e = new Contacto();
		}
		
		
		int status=0;
		//Esto habira que ponerlo despues.
		
		try{
			for(int i=0; i<e.getIntereses().size();i++) {
				
				PreparedStatement ps2=con.prepareStatement(config.getProperty("INSERTAR_INTERES_CONTACTO"));
				ps2.setString(1, e.getEmail().toLowerCase());
				ps2.setInt(2, e.getIntereses().get(i).getId());
				System.out.println("Vamos a insertarle a "+e.getNombre()+ " el interes: "+ e.getIntereses().get(i).getInteres());
				status= ps2.executeUpdate();
				
				if(status!=1) {
					System.out.println("Error al añadir los intereses de un usuario");
				}
				
			}
			
			
			PreparedStatement ps=con.prepareStatement(config.getProperty("INSERTAR_CONTACTO"));
			
			ps.setString(1,e.getEmail().toLowerCase());
			ps.setString(2,e.getNombre());
			ps.setString(3,e.getApellidos());
			ps.setDate(4, e.getFechanacimiento());
			ps.setString(5, e.getPassword());
			
			status = ps.executeUpdate();
			if(status!=1) {
				System.out.println("Error al añadir el contacto");
			}
			
		} catch(Exception es) { 
				es.printStackTrace();
				
		}
		
		if(status!=1) {
			System.out.println("No se ha podido añadir el contacto a la base de datos");
		}
		
		//Actualiza los destinatarios de los anuncios.
		ArrayList<Contacto> aux = new ArrayList<Contacto>();
		for(Anuncio a: anunciosDAO.getAnuncios()) {
			//COmprobar argumentos del if. ACTUALIZAR
			if(a.getClass().toString().equals("class ejercicio1.AnuncioFlash") || a.getClass().toString().equals("class ejercicio1.AnuncioGeneral")) {
				
				PreparedStatement ps=con.prepareStatement(config.getProperty("INSERTAR_DESTINATARIOS"));
		        ps.setInt(2, a.getId());
		        ps.setString(1, e.getEmail());
		        status = ps.executeUpdate();
		        
		        if(status!=1) {
		        	System.out.println("Error al añadir el usuario como destinatario del anuncio :"+a.getTitulo());
		        }
			}
			
		}
		

	}

	@Override
	public void borrarContacto(Contacto e) throws SQLException, FileNotFoundException, ClassNotFoundException, IOException {
		anunciosDAO=factory.getAnuncioDAO();
		if(e==null) {
			System.out.println("No existe un contacto con dichos atributos");
			return;
		}
		
		int status=0;
			
		PreparedStatement ps=con.prepareStatement(config.getProperty("BORRAR_CONTACTO"));
		ps.setString(1,e.getEmail());
		status=ps.executeUpdate();

		if(status!=1) {
			System.out.println("No se ha podido eliminar el contacto de la base de datos");
		}
		
		//Actualiza los intereses de los contactos y los destinatarios.
        
        //Si funciona lo del delete on cascade esto no hace falta :D. No funciona D:
		PreparedStatement ps2=con.prepareStatement(config.getProperty("BORRAR_INTERESES_CONTACTO"));
        ps2.setString(1, e.getEmail());
        status = ps2.executeUpdate();
        
        if(status<1) {
			System.out.println("No se ha podido eliminar los intereses contacto de la base de datos");
		}
        
        PreparedStatement ps1=con.prepareStatement(config.getProperty("BORRAR_DESTINATARIO_EMAIL"));
        ps1.setString(1, e.getEmail());
        status = ps1.executeUpdate();
        if(status<1) {
			System.out.println("No se ha podido eliminar como destinatario el contacto seleccionado");
		}
       
	}
	
	
	public void actualizarContactoNombre(Contacto a, String nombreaux) throws SQLException {
        
        int status=0;
        PreparedStatement ps=con.prepareStatement(config.getProperty("MODIFICAR_NOMBRE_CONTACTO"));
        ps.setString(1, nombreaux);
        ps.setString(2,a.getEmail());
        status = ps.executeUpdate();
		if(status!=1) {
			System.out.println("Error al actualizar en la base de datos");
		}
		
	}
	
	public void actualizarContactoApellido(Contacto a, String apellidos) throws SQLException {
		int status=0;
		PreparedStatement ps=con.prepareStatement(config.getProperty("MODIFICAR_APELLIDOS_CONTACTO"));
	    ps.setString(1, apellidos);
	    ps.setString(2, a.getEmail());
	    status = ps.executeUpdate();
		if(status!=1) {
			System.out.println("Error al actualizar en la base de datos");
		}
		
	}
	
	public void actualizarContactoFecha(Contacto a, String fecha) throws SQLException {
		Integer status =0;
		
		Date dnuevafecha = Date.valueOf(fecha);
		PreparedStatement ps=con.prepareStatement(config.getProperty("MODIFICAR_FECHANACIMIENTO_CONTACTO"));
		ps.setDate(1, dnuevafecha);
		ps.setString(2, a.getEmail());
		status = ps.executeUpdate();
		if(status!=1) {
			System.out.println("Error al actualizar en la base de datos");
		}
		
	}
	//REVISAR BIEN ESTAS DOS FUNCIONES. Se pueden optimizar para no tener que pasar a interes, ya que son int en strings en un principio como parametro
	public void actualizarContactoInteresDelete(Contacto a, String[] intereses) throws SQLException{
		
		ArrayList<Integer> interesList = new ArrayList<Integer>();
		//Para pasar de String[] a ArrayList de Intereses. 
		
		for(String s:intereses) {
			interesList.add(Integer.parseInt(s));
		}
		
		
		int status=0;
		for(Integer j: interesList) {
			PreparedStatement ps=con.prepareStatement(config.getProperty("BORRAR_INTERES_CONTACTO"));
			ps.setInt(1,j);
			ps.setString(2,a.getEmail());
			status=ps.executeUpdate();
			
			if(status!=1) {
				System.out.println("No se ha borrado el interes...");
			}
		}
		
	}
	
	public void actualizarContactoInteresAdd(Contacto a, String[] intereses) throws SQLException{
		
		ArrayList<Integer> interesList = new ArrayList<Integer>();
		
		for(String s:intereses) {			
			interesList.add(Integer.parseInt(s));
		}
		
		
		int status=0;
		for(Integer j: interesList) {
			PreparedStatement ps=con.prepareStatement(config.getProperty("INSERTAR_INTERES_CONTACTO"));
			ps.setInt(2,j);
			ps.setString(1,a.getEmail());
			status=ps.executeUpdate();
			
			if(status!=1) {
				System.out.println("No se ha añadido el interes...");
			}
		}
		
	}
	
	public Contacto buscarContactoEmail(String email) throws SQLException {
		PreparedStatement ps=con.prepareStatement(config.getProperty("OBTENER_CONTACTOS_EMAIL"));
		ArrayList<Integer> interesesid=new ArrayList<Integer>();
		ArrayList<Interes> intereses = new ArrayList<Interes>();
		PreparedStatement ps2;
		Contacto contacto=null;
		ResultSet rs2;
		try {
			
			ps.setString(1,email);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()) {
				
				ps2=con.prepareStatement(config.getProperty("OBTENER_INTERESES_CONTACTO"));
				ps2.setString(1, rs.getString(1));
				rs2=ps2.executeQuery();
				while(rs2.next()) {
					interesesid.add(rs2.getInt(2));
				}
				
				for(Interes i: interesesDAO.getIntereses()) {
					if(interesesid.contains(i.getId())) {
						intereses.add(i);
					}
				}
				contacto = new Contacto(rs.getString(1),rs.getString(2),rs.getString(3), rs.getDate(4),rs.getString(5),intereses);
				return contacto;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("No hay ningun usuario con dicho email.");
		return contacto;
	}
	
	
	
	/*public String imprimirContacto(String a, String b, String string, String d) {
		//Mirar algo para formatear fecha sql.date.
		String cadena= "Nombre: "+a+ " Apellidos: "+b+" Fecha de Nacimiento: "+string+" Email: "+d;
		return cadena;
	}*/
	
	public void mostrarContactos() throws SQLException {
		ArrayList<Contacto> listaContactos=new ArrayList<Contacto>();
		listaContactos=getContactos();
		for(Contacto e: listaContactos) {
			System.out.println(e.getEmail()+" "+e.getNombre());
		}
	}
	//Revisar
	public void añadirInteres(Contacto e) throws SQLException {
		Scanner sc=new Scanner(System.in);
		
		ArrayList<Interes> aux=interesesDAO.getInteresesContacto(e.getEmail());
		
		ArrayList<Interes> listaintereses=new ArrayList<Interes>();
		listaintereses=interesesDAO.getIntereses();
		for(int i=0; i<listaintereses.size();i++) {
			for(Interes j: aux) {
				
				if(j.getId()==listaintereses.get(0).getId()){
					
				}
				else {
					System.out.println(listaintereses.get(i).getId() +". "+ listaintereses.get(i).getInteres());
				}
				
			}
		}
		
		System.out.print("Que interes añadir: ");
		
		Integer linea;
		linea = sc.nextInt();
		sc.nextLine();
		PreparedStatement ps=con.prepareStatement(config.getProperty("INSERTAR_INTERES_CONTACTO"));

		ps.setInt(2,linea);
		ps.setString(1,e.getEmail());
		int status=0;
		status=ps.executeUpdate();
		if(status!=1) {
			System.out.println("Error al insertar el nuevo interes");
		}
		
	}
	

}//Fin de la clase	