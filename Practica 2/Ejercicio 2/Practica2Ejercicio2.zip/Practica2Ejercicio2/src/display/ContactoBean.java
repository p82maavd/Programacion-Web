package display;

import java.util.ArrayList;

import business.Interes;

public class ContactoBean implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private String emailUser = "";
	private String passwordUser= "";
	private ArrayList<Interes> interesesUser;

	public String getEmailUser() {
		return emailUser;
	}

	public void setEmailUser(String emailUser) {
		this.emailUser = emailUser;
	}

	public String getPasswordUser() {
		return passwordUser;
	}

	public void setPasswordUser(String passwordUser) {
		this.passwordUser = passwordUser;
	}

	public ArrayList<Interes> getInteresesUser(){
		return interesesUser;
	}
	
	public void setInteresesUser(ArrayList<Interes> interesesUser) {
		this.interesesUser=interesesUser;
	}
	
}