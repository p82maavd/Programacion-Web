package display;

import java.util.ArrayList;

import business.Interes;

public class InteresesBean implements java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private ArrayList<Interes> intereses;
	
	public ArrayList<Interes> getIntereses(){
		return intereses;
	}
	
	public void setIntereses(ArrayList<Interes> intereses) {
		this.intereses=intereses;
	}

	

}