package bussines;

public class Interes {

	private int id;
	
	private String interes;
	
	public Integer getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getInteres() {
		return interes;
	}
	public void setInteres(String interes) {
		this.interes = interes;
	}
	public Interes(int id, String interes) {
		
		this.id = id;
		this.interes = interes;
	}
}