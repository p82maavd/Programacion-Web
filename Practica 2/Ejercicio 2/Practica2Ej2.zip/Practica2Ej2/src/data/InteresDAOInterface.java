package data;

import java.sql.SQLException;
import java.util.ArrayList;
import bussines.Interes;

public interface InteresDAOInterface {
	
	public void crearInteres();

	public ArrayList<Interes> getIntereses() throws SQLException;

}